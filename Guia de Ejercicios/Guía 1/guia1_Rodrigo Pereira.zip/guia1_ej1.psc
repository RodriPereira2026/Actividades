Algoritmo sin_titulo
	Definir operacion, res Como Entero
	Escribir "Ingrese un n�mero"
	Leer operacion
	res= operacion * operacion * operacion
	Escribir "El resultado es: " res
FinAlgoritmo
