Algoritmo sin_titulo
	Definir num1, num2, suma, resta, multi, divi Como Entero
	Escribir "Ingresar el primer n�mero"
	Leer num1
	Escribir "Ingresar el segundo n�mero"
	Leer num2
	
	suma= num1 + num2
	resta= num1 - num2
	multi= num1 * num2
	divi= num1 / num2
	
	Escribir "La suma es: " suma
	Escribir "La resta es: " resta
	Escribir "La multiplicaci�n es: " multi
	Escribir "La divisi�n es: " divi
FinAlgoritmo
