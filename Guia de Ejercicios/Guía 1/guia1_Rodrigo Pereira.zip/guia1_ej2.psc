Algoritmo sin_titulo
	Definir anioActual, anioNacimiento, edad Como Entero
	Escribir "Ingrese el a�o actual"
	Leer anioActual
	Escribir "Ingrese tu a�o de nacimiento"
	Leer anioNacimiento
	edad= anioActual - anioNacimiento
	Escribir "La edad tiene: " edad
FinAlgoritmo
